"""
WISeR Packet Dashboard Backend - FastAPI Application
"""
__version__ = "1.0.0"
